ST VL53L0X ToF laser distance sensor. I used ST API to run this sensor.
Continuous measurement using interrupts.

STM43F401CC (https://sklep.msalamon.pl/produkt/stm32f401ccu6-dev-board/)
STM32CubeIDE 1.1.0
HAL F4 1.24.2

Description: https://msalamon.pl/obsluga-przerwaniowa-czujnika-laserowego-vl53l0x/
GitHub:  https://github.com/lamik/VL53L0X_API_INT_STM32_HAL
Contact: mateusz@msalamon.pl